package com.example.kotlinfloweksempel1.TestModel

data class TestModel(val id: Int?, val content: String, val user: String, val totalComments: Int?)